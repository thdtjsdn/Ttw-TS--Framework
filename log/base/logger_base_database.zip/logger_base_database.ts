//import { DataBaseInterfaces } from "../../database/file/node_json_db/database_interfaces";

import { AppLogger } from "../app_logger";
import { LoggerBase } from "./logger_base";

import { LoggerInterfaces } from "../interfaces/logger_interfaces";

export class LoggerBaseDatabase implements LoggerInterfaces{

	//static name: string = 'LoggerBaseDatabase';
	
	constructor(){}

	static debug_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.debug(message, context);

		try{
			database.push('/debug/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 24, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	static error_db(database:DataBaseInterfaces, message: string, stack?: string, context?: any): void{
		const a: Array<any> = LoggerBase.error(message, stack, context);
		
		try{
			database.push('/error/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 40, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	static log_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.log(message, context);

		try{
			database.push('/log/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 62, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	/**
	 * complete log
	 * @param message 
	 * @param context 
	 */
	static logc_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.logc(message, context);

		try{
			database.push('/log/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 89, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	/**
	 * ...ing log
	 * @param message 
	 * @param context 
	 */
	static logi_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.logi(message, context);

		try{
			database.push('/log/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 116, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	/**
	 * red color log
	 * @param message 
	 * @param context 
	 */
	static logr_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.logr(message, context);

		try{
			database.push('/log/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 143, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	/**
	 * yellow color log
	 * @param message 
	 * @param context 
	 */
	static logy_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.logy(message, context);

		try{
			database.push('/log/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 170, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	static verbose_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.log(message, context);

		try{
			database.push('/verbose/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 192, this);
			}
			catch(er){
				debugger;
			}
		}
	};

	static warn_db(database:DataBaseInterfaces, message: string, context?: any): void{
		const a: Array<any> = LoggerBase.log(message, context);

		try{
			database.push('/warn/' + a[0], a[1]);
		}
		catch(er){
			try{
				AppLogger.error(er, this.name + " / " + 172, this);
			}
			catch(er){
				debugger;
			}
		}
	};
}