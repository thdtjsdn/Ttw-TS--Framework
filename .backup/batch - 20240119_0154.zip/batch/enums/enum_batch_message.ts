export enum EnumBatchMessage {
	  MSG_COLLECT_COMPLETE_PAGE = 'Page collection complete - restart in 10 minutes'
	, MSG_COLLECT_STATUS_PAGE = 'Page collection status'
	, MSG_ERROR_502 = 'ResponseStatus(502) - Restart in 10 minutes'
}