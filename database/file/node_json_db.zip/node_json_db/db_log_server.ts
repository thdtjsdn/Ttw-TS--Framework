import { DBLogger } from "../../../log/db_logger";

import { DBFileNodeJsonDB_Base } from "./db_base";
import { DataBaseInterfaces } from "./database_interfaces";

export class DBFileNodeJsonDB_LogServer extends DBFileNodeJsonDB_Base implements DataBaseInterfaces {
	name: string = this.constructor.name;

	constructor(database_path: string = './database/db_log_server') {
		super(database_path);
	}

	override delete(key: string){
		this.database.delete(key);
		DBLogger.warn(`Delete - ${key}`, this);
	}

	override regenerationDB(){
		try{
			this.database = new this.JsonDB(this.database_path, true, false);
		}catch(er){
			DBLogger.error(`DB regeneration error`, this.name + '/' + 22, this);
		}
	}

	override reload(){
		this.database.reload();
		DBLogger.warn(`DB reaload`, this);
	}
}