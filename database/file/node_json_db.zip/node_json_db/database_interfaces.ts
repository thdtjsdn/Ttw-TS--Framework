export interface DataBaseInterfaces {
	delete(key: string);
	push(key: string, value: any);
	regenerationDB();
	reload();
	getData(key: string);

	get databasePath(): string;
	//get database(): any;
}