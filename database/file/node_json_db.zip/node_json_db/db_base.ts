import { DataBaseInterfaces } from "./database_interfaces";

import { AppLogger } from "../../../log/app_logger";

export class DBFileNodeJsonDB_Base implements DataBaseInterfaces {
	name: string = this.constructor.name;

	JsonDB = require('node-json-db');

	database_path: string = '';
	database: any;

	constructor(database_path: string) {
		this.database_path = database_path;
		this.database  = new this.JsonDB(this.database_path, true, false);
	}

	delete(key: string){
		this.database.delete(key);
		AppLogger.warn(`Delete - ${key}`, this);
	}

	push(key: string, value: any){
		this.database.push(key, value);
	}

	regenerationDB() {
		try{
			this.database = new this.JsonDB(this.database_path, true, false);
		}catch(er){
			AppLogger.error(`DB regeneration error`, this.name + '/' + 27, this);
		}
	}

	reload() {
		this.database.reload();
		AppLogger.warn(`DB reaload`, this);
	}

	getData(key: string) {
		return this.database.getData(key);
	}

	get databasePath(): string {
		return this.database_path;
	}
}