import { DBFileNodeJsonDB_Base } from "./db_base";
import { DataBaseInterfaces } from "./database_interfaces";

import { DBLogger } from "../../../log/db_logger";

export class DBFileNodeJsonDB_Batch extends DBFileNodeJsonDB_Base implements DataBaseInterfaces {
	name: string = this.constructor.name;
	
	constructor(database_path: string = './database/db_transaction_merge') {
		super(database_path);
	}

	override delete(key: string){
		this.database.delete(key);
		DBLogger.warn(`Delete - ${key}`, this);
	}

	override regenerationDB(){
		try{
			this.database = new this.JsonDB(this.database_path, true, false);
		}catch(er){
			DBLogger.error(`DB regeneration error`, this.name + '/' + 27, this);
		}
	}

	override reload(){
		this.database.reload();
		DBLogger.warn(`DB reaload`, this);
	}
}