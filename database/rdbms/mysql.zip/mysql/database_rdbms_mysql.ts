import { DatabaseNoSQLBase } from "../../nosql/base/database_nosql_base";
import { DatabaseNoSQLInterfaces } from "../../nosql/interfaces/database_nosql_interfaces";

export class DatabaseRDBMSMySQL extends DatabaseNoSQLBase implements DatabaseNoSQLInterfaces {

	name: string = this.constructor.name;

	/**
	 * 
	 * @param binaryPathDBMS 
	 * @param binaryPathDBMSClient 
	 * @param host 
	 * @param port 
	 * @param userId 
	 * @param password 
	 */
	constructor(binaryPathDBMS: String, binaryPathDBMSClient: String, host: String, port: Number, userId: String, password: String) {
		super(binaryPathDBMS, binaryPathDBMSClient, host, port, userId, password);
	}


	/**
	 * 
	 * @param cbComplete 
	 * @param query 
	 */
	executeQuery(cbComplete: Function, query: String): void{
		UtilCLIDatabaseNoSQLMongoDB.executeQuery(
			cbComplete
			, query
			, this.BINARY_PATH_DBMS_Client
			, this.ACCOUNT_USER_ID
			, this.ACCOUNT_PASSWORD
			, this.host
			, this.port);
	}

	/**
	 * 
	 * @param cbComplete 
	 * @param queryFilePath 
	 */
	executeQueryFile(cbComplete: Function, queryFilePath: String): void {
		UtilCLIDatabaseNoSQLMongoDB.executeQueryFile(
			cbComplete
			, queryFilePath
			, this.BINARY_PATH_DBMS_Client
			, this.ACCOUNT_USER_ID
			, this.ACCOUNT_PASSWORD
			, this.host
			, this.port);
	}

	/**
	 * 
	 * @param query
	 * @returns 
	 */
	syncExecuteQuery(query: String): String {
		return UtilCLIDatabaseNoSQLMongoDB.syncExecuteQuery(
			query
			, this.BINARY_PATH_DBMS_Client
			, this.ACCOUNT_USER_ID
			, this.ACCOUNT_PASSWORD
			, this.host
			, this.port);
	}

	/**
	 * 
	 * @param queryFilePath 
	 * @returns 
	 */
	syncExecuteQueryFile(queryFilePath: String): String {
		return UtilCLIDatabaseNoSQLMongoDB.syncExecuteQueryFile(
			queryFilePath
			, this.BINARY_PATH_DBMS_Client
			, this.ACCOUNT_USER_ID
			, this.ACCOUNT_PASSWORD
			, this.host
			, this.port);
	}


	restart(): DatabaseNoSQLMongoDB {
		return this;
	}

	start(): DatabaseNoSQLMongoDB {
		return this;
	}

	stop(): DatabaseNoSQLMongoDB {
		return this;
	}
}