"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatabaseRDBMSMySQL = void 0;
class DatabaseRDBMSMySQL extends DatabaseNoSQLBase {
    /**
     *
     * @param binaryPathDBMS
     * @param binaryPathDBMSClient
     * @param host
     * @param port
     * @param userId
     * @param password
     */
    constructor(binaryPathDBMS, binaryPathDBMSClient, host, port, userId, password) {
        super(binaryPathDBMS, binaryPathDBMSClient, host, port, userId, password);
        this.name = this.constructor.name;
    }
    /**
     *
     * @param cbComplete
     * @param query
     */
    executeQuery(cbComplete, query) {
        UtilCLIDatabaseNoSQLMongoDB.executeQuery(cbComplete, query, this.BINARY_PATH_DBMS_Client, this.ACCOUNT_USER_ID, this.ACCOUNT_PASSWORD, this.host, this.port);
    }
    /**
     *
     * @param cbComplete
     * @param queryFilePath
     */
    executeQueryFile(cbComplete, queryFilePath) {
        UtilCLIDatabaseNoSQLMongoDB.executeQueryFile(cbComplete, queryFilePath, this.BINARY_PATH_DBMS_Client, this.ACCOUNT_USER_ID, this.ACCOUNT_PASSWORD, this.host, this.port);
    }
    /**
     *
     * @param query
     * @returns
     */
    syncExecuteQuery(query) {
        return UtilCLIDatabaseNoSQLMongoDB.syncExecuteQuery(query, this.BINARY_PATH_DBMS_Client, this.ACCOUNT_USER_ID, this.ACCOUNT_PASSWORD, this.host, this.port);
    }
    /**
     *
     * @param queryFilePath
     * @returns
     */
    syncExecuteQueryFile(queryFilePath) {
        return UtilCLIDatabaseNoSQLMongoDB.syncExecuteQueryFile(queryFilePath, this.BINARY_PATH_DBMS_Client, this.ACCOUNT_USER_ID, this.ACCOUNT_PASSWORD, this.host, this.port);
    }
    restart() {
        return this;
    }
    start() {
        return this;
    }
    stop() {
        return this;
    }
}
exports.DatabaseRDBMSMySQL = DatabaseRDBMSMySQL;
